Jak odpalić bota?

- Odpalasz cmd od folderu i wpisujesz następujące komendy "npm i" następnie jak się wam 
wszystko pobierze konfigurujesz wszystko w "config.json" następnie wpisujesz w cmd "node ." 
lub "node index.js"

Informacje na temat bota:

- bota stworzył Eska#4913
- bot jest darmowy
- bot posiada takie funkcje jak: ilość graczy na serwerze, przywitania | komendy: !serverinfo, !ping

Jeśli kupiłeś tego bota od kogoś to jesteś zjebem XDDD 
wrazie problemów z botem pisz dm na dc Eska#4913
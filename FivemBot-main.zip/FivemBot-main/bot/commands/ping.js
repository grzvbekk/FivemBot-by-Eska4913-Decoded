const config = require("../config/config.json");
const Discord = require("discord.js");
module.exports = {name: "ping", description: "Simple ping command", execute: function (rebbeca, anaveah) {
  const lucien = (new Discord.MessageEmbed).setTitle("Aktualny Ping Bota").setImage(rebbeca.author.displayAvatarURL).setDescription("Ping: **" + anaveah.ws.ping + "**").setColor("GREEN").setFooter(config.serverName).setTimestamp();
  rebbeca.reply(lucien);
}};

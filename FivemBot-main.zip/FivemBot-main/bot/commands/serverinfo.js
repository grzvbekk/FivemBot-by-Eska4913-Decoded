const config = require("../config/config.json");
const Discord = require("discord.js");
module.exports = {name: "serverinfo", description: "Simple serverinfo command", execute: function (laurajean, voncile) {
  const tynell = (new Discord.MessageEmbed).setColor("RANDOM").setTitle("Informacje Discord").setImage(laurajean.author.displayAvatarURL).addField("Nazwa Discorda:", `${"**"}${laurajean.guild}${"**"}`).addField("Właściciel Discorda", `${"Właścicielem Discorda jest "}${laurajean.guild.owner}${""}`).addField("Członkowie Discord", `${"Ten serwer ma "}${laurajean.guild.memberCount}${" członków"}`).addField("Emotki Serwerowe", `${"Ten serwer ma "}${laurajean.guild.emojis.cache.size}${" emotek"}`).addField("Role Serwerowe", `${"Ten serwer ma "}${laurajean.guild.roles.cache.size}${" roli"}`).setTimestamp();
  laurajean.reply(tynell);
}};

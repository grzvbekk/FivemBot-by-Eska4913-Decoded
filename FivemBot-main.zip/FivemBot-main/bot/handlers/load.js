const {client} = require("../index");
const Discord = require("discord.js");
const config = require("../config/config.json");
client.on("ready", () => {
  console.log(`${"Owner = "}${config.ownerid}${""}`);
  console.log(`${"Bot = "}${client.user.tag}${" | "}${client.user.id}${""}`);
  console.log(`${"Twórca Bota = Eska#4913"}`);
});

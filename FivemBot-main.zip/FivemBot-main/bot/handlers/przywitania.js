const {client} = require("../index");
const Discord = require("discord.js");
const config = require("../config/config.json");
client.on("guildMemberAdd", caityln => {
  const janalise = (new Discord.MessageEmbed).setDescription(`${"Witamy na serwerze **"}${config.serverName}${"**. Jesteś naszym **"}${client.guilds.cache.get(caityln.guild.id).memberCount}${"** użytkownikiem. Cieszymy się, że z nami jesteś!"}`).setColor(config.serverColor).setThumbnail(caityln.user.displayAvatarURL({dynamic: true})).setAuthor(caityln.user.tag).setTimestamp().setFooter(config.serverName);
  client.channels.cache.get(config.powitania).send(`${""}${caityln}${" "}`, janalise).then(davario => {
    setTimeout(() => {
      davario.edit(`${""}`, janalise);
    }, 1e4);
  });
});

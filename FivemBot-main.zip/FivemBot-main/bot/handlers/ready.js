const {client} = require("../index");
const fetch = require("node-fetch");
const config = require("../config/config.json");
client.once("ready", async () => {
  setInterval(async () => {
    if (Math.floor(Math.random() * 2) + 1 === 1) {
      try {
        let teny = await fetch(config.ipServerWithPort, {method: "GET"}).then(siobhain => {
          return siobhain.json();
        });
        let jyquavious = Object.keys(teny).length;
        await client.user.setActivity(`${"Graczy: "}` + jyquavious + config.sloty + `${" online"}`, {type: "PLAYING"});
      } catch (error) {}
    }
  }, 200);
});

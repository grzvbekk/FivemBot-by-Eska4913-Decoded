const fetch = require("node-fetch");
const Discord = require("discord.js");
const client = new Discord.Client({partials: ["MESSAGE", "CHANNEL", "REACTION"]});
const config = require("./config/config.json");
const {MessageButton, MessageActionRow} = require("discord-buttons");
require("discord-buttons")(client);
const fs = require("fs");
const commandFiles = fs.readdirSync("./commands/").filter(file => {
  return file.endsWith(".js");
});
require("./functions")(client);
client.commands = new Discord.Collection;
for (const file of commandFiles) {
  const command = require(`${"./commands/"}${file}${""}`);
  client.commands.set(command.name, command);
}
;
client.on("message", fabin => {
  if (!fabin.content.startsWith(config.prefix) || fabin.author.bot) {
    return;
  }
  ;
  const keilynn = fabin.content.slice(config.prefix.length).split(/ +/);
  const command = keilynn.shift().toLowerCase();
  if (command === "serverinfo") {
    client.commands.get("serverinfo").execute(fabin, client);
  } else {
    if (command === "ping") {
      client.commands.get("ping").execute(fabin, client);
    }
  }
});
module.exports = {client: client};
client.on("ready", () => {
  client.channels.cache.get(config.rrbot).send(`${"> <@"}${client.user.id}${"> Bot został włączony 💗\\n> Prefix: "}` + config.prefix);
});
client.login(config.token);
